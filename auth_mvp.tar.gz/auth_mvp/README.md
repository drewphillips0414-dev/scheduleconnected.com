# Auth MVP - Extensible Flask Application

A minimum viable product with user registration, secure login, and a basic dashboard.

## Features
- User registration with username, email, and password
- Secure password hashing (bcrypt)
- Session-based login with Flask-Login
- CSRF protection
- Protected dashboard
- Modular blueprint architecture for easy extension

## Setup

1. Create a virtual environment:
   ```bash
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   ```

2. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

3. Set environment variables (or use .env):
   ```bash
   export FLASK_APP=run.py
   export FLASK_SECRET_KEY="your-very-long-random-secret-key-here"
   ```

4. Run the application:
   ```bash
   flask run --debug
   # or
   python run.py
   ```

5. Open http://127.0.0.1:5000

## Architecture

- `app/__init__.py` - Application factory
- `app/models.py` - Database models
- `app/auth/` - Authentication blueprint (register, login, logout)
- `app/main/` - Main blueprint (dashboard, etc.)
- `templates/` - Jinja2 templates
- Easy to add new blueprints for additional features

## Security Notes

- Passwords are hashed with bcrypt
- Sessions use secure cookies (configure for production HTTPS)
- CSRF tokens on all forms
- Change SECRET_KEY for production
- Use a proper database (PostgreSQL) and server (Gunicorn) for production

## Extending

Add new features by creating additional blueprints in `app/` and registering them in the application factory.
